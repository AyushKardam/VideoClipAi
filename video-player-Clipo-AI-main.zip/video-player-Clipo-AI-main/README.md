This project is a web-based video player developed using React.js, providing users with a customizable experience for subtitles. Users can play, pause, seek through videos, and adjust subtitle settings such as font size, color, and background. Additionally, users have the option to upload custom subtitle files in popular formats like SRT and VTT.

Made By-Aryan Agrawal